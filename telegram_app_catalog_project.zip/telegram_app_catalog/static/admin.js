const form=document.querySelector('#form'),status=document.querySelector('#status');let editing=null;
const headers={'Content-Type':'application/json'};
async function api(url,opts={}){const r=await fetch(url,opts);if(!r.ok)throw new Error((await r.text())||r.statusText);return r.status===204?null:r.json();}
async function init(){
 const cats=await api('/api/categories');document.querySelector('#category').innerHTML=cats.map(c=>`<option>${c}</option>`).join('');
 await refresh();
}
function payload(){const d=Object.fromEntries(new FormData(form));d.rating=Number(d.rating||0);return d;}
async function refresh(){
 const items=await api('/api/apps');const list=document.querySelector('#list');list.innerHTML='';
 items.forEach(x=>{const el=document.createElement('div');el.className='item';const info=document.createElement('div');const title=document.createElement('b');title.textContent=x.name;const sub=document.createElement('small');sub.textContent=`${x.category} · ★ ${x.rating}`;info.append(title,document.createElement('br'),sub);
 const actions=document.createElement('div');const edit=document.createElement('button');edit.className='primary';edit.textContent='Изменить';edit.onclick=()=>{editing=x.id;for(const [k,v] of Object.entries(x)){if(form.elements[k])form.elements[k].value=v;}document.querySelector('#formTitle').textContent='Изменить приложение';window.scrollTo({top:0,behavior:'smooth'});};
 const del=document.createElement('button');del.className='danger';del.textContent='Удалить';del.onclick=async()=>{if(confirm('Удалить приложение?')){try{await api('/api/apps/'+x.id,{method:'DELETE'});await refresh();}catch(e){alert('Не удалось удалить: '+e.message)}}};actions.append(edit,del);el.append(info,actions);list.append(el);});
}
form.onsubmit=async e=>{e.preventDefault();try{const url=editing?'/api/apps/'+editing:'/api/apps';await api(url,{method:editing?'PUT':'POST',headers,body:JSON.stringify(payload())});status.textContent='Сохранено';form.reset();editing=null;document.querySelector('#formTitle').textContent='Добавить приложение';await refresh();}catch(err){status.textContent='Ошибка: '+err.message;}};
document.querySelector('#cancel').onclick=()=>{form.reset();editing=null;document.querySelector('#formTitle').textContent='Добавить приложение';status.textContent='';};
init().catch(e=>status.textContent='Ошибка загрузки: '+e.message);
